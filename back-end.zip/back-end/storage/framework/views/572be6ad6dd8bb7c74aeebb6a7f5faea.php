<?php echo e($slot); ?>

<?php /**PATH C:\Users\Dell\Desktop\api-auth\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>